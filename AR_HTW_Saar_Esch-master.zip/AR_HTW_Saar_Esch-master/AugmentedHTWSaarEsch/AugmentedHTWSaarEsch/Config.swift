//
//  Config.swift
//  AugmentedRealityHTWSaar
//
//  Created by Marco Becker on 13.08.18.
//  Copyright © 2018 AugmentedReality. All rights reserved.
//

import Foundation

/*
 Klasse zum ändern der URL. Wird zum testen im Netz des Servers benötigt.
 */
class Config{
   // let url: String = "http://192.168.0.101:1337";
    let url: String = "http://augmentedhtwsaar.ddns.net:1337";
}
