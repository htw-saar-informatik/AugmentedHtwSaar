package locals;

public class ErrorsEN {

        //Database errors
        public static final String DATABASE_CONNECT_FIRST = "You are not connected to a database. Please use the function connect() to connect to a database first!";
        public static final String DATABASE_CONNECTION_FAILED = "Cannot connect to the database. Please check the configs in the database.properties file!";

    }
