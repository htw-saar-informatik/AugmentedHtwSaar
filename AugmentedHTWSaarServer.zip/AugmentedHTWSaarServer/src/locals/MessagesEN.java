package locals;

public class MessagesEN {

    //Database
    public static final String DATABASE_CONNECTED_1 = "Successfully connected to database <";
    public static final String DATABASE_CONNECTED_2 = "> on ";
    public static final String DATABASE_CONNECTED_3 = " ! :)";
}
