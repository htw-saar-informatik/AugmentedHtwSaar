package Service;

import javax.ws.rs.Path;

public class SchwarzesBrettService {
}
