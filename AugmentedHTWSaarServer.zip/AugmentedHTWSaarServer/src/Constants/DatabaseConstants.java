package Constants;

/**
 * Klasse um Konstanten für die Datenbank zu definieren und zu konfigurieren
 */
public class DatabaseConstants {
    public static final int DATABASE_TIMEOUT = 1;
}
